package com.sistemadematricula.examenG1RIVERA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenG1RiveraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenG1RiveraApplication.class, args);
	}

}
