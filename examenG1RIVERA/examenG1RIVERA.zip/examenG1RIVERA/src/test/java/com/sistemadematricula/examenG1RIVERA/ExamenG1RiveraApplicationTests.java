package com.sistemadematricula.examenG1RIVERA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenG1RiveraApplicationTests {

	@Test
	void contextLoads() {
	}

}
